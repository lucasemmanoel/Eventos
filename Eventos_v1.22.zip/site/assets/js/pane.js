/*
 * ------------------------------------------------------------------------
 * P22Eventos - Version 1.0
 * ------------------------------------------------------------------------
 * Copyright (C) 2011
 * Author: Porta22 - Hugo Seabra
 * E-mail: hugo@porta22.com.br
 * Websites: http://porta22.com.br
 * This file may not be redistributed in whole or significant part.
 * Created on : 05/07/2011, 23:40:08
 * @license GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 *
 * ------------------------------------------------------------------------
 */

eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('b.d(\'a\',2(){9 7($$(\'.3 8.1-0\'),$$(\'.3 c.1-h\'),{e:2(0,i){0.5(\'1-0-6\');0.4(\'1-0\')},l:2(0,i){0.5(\'1-0\');0.4(\'1-0-6\')},k:g,f:j})});',22,22,'toggler|jpane|function|panel|removeClass|addClass|down|Accordion|h3|new|domready|window|div|addEvent|onActive|opacity|300|slider||false|duration|onBackground'.split('|'),0,{}))